# AISZ GAME PANEL (Android 15 starter project)

A starter Android Studio project for a draggable overlay shortcut panel. It does not require root or Shizuku.

## Important device limitation

Xiaomi's official POCO C65 FAQ says the phone does not support Xiaomi's built-in Floating feature or split screen, and Xiaomi says POCO C65 does not support Game Turbo. Android freeform windows are device/OEM dependent. Therefore this project **does not claim to display arbitrary apps as true resizable floating windows**.

The panel can appear over a game when Android grants overlay permission and usage access. It detects apps marked by Android as games; some games may not be categorized correctly. Selecting an app launches it normally and may take you away from the game. It does not embed another app's Activity inside the overlay.

## Permissions

1. Display over other apps (`SYSTEM_ALERT_WINDOW`).
2. Usage access (`PACKAGE_USAGE_STATS`) for foreground app detection.
3. Foreground service notification.

Grant permissions only if you understand what they do. The panel can be stopped from the app's settings or by force-stopping it.

## Build APK on GitHub from a phone

1. Create a new repository on GitHub and upload all files in this project.
2. Open the repository's **Actions** tab.
3. Select **Build AISZ GAME PANEL APK**, then tap **Run workflow**.
4. When the workflow finishes, open the run and download the `AISZ-GAME-PANEL-debug-apk` artifact.
5. Extract the downloaded ZIP to get `app-debug.apk`. Android may ask you to allow installing apps from the browser/file manager.

The APK produced by this workflow is a debug build for personal testing, not a Play Store release.

## Project

- Package: `com.aisz.gamepanel`
- Target SDK: 35 (Android 15)
- Min SDK: 26 (Android 8.0)
- No root/Shizuku integration
