package com.aisz.gamepanel

import android.app.AppOpsManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class PanelService : Service() {
    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var bubble: TextView? = null
    private var panel: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var shownForGame = false
    private val blue = Color.rgb(57, 133, 255)
    private val dark = Color.rgb(14, 22, 39)
    private val card = Color.rgb(27, 41, 64)
    private val white = Color.WHITE
    private val muted = Color.rgb(185, 199, 220)

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel()
        startForeground(17, notification())
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Aktifkan izin tampil di atas aplikasi", Toast.LENGTH_LONG).show()
            stopSelf(); return
        }
        createBubble()
        handler.post(pollRunnable)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("aisz_panel", "AISZ Game Panel", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "aisz_panel") else Notification.Builder(this)
        return builder.setContentTitle("AISZ GAME PANEL aktif")
            .setContentText("Memantau aplikasi game untuk menampilkan panel pintasan")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true).build()
    }

    private fun createBubble() {
        if (bubble != null) return
        val view = TextView(this).apply {
            text = "A"
            textSize = 20f
            gravity = Gravity.CENTER
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            background = shape(blue, 100)
            elevation = dp(8).toFloat()
            setOnClickListener { togglePanel() }
            setOnTouchListener(DragTouchListener())
            visibility = View.GONE
        }
        val p = WindowManager.LayoutParams(dp(54), dp(54), overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8); y = dp(220)
        }
        try { wm.addView(view, p); bubble = view; bubbleParams = p } catch (_: Exception) { stopSelf() }
    }

    private fun togglePanel() {
        if (panel != null) { removePanel(); return }
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = shape(dark, 22)
            elevation = dp(12).toFloat()
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(label("AISZ GAME PANEL", 17f, white, true), LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(label("×", 25f, white, true).apply {
            gravity = Gravity.CENTER
            setOnClickListener { removePanel() }
        }, LinearLayout.LayoutParams(dp(34), dp(34)))
        outer.addView(header)
        outer.addView(label("Pintasan aplikasi • tanpa root/Shizuku", 11f, muted, false), margins(0, 3, 0, 10))
        outer.addView(label("Catatan: aplikasi yang dipilih terbuka normal, bukan di jendela bebas.", 12f, muted, false), margins(0, 0, 0, 10))
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val apps = try {
            packageManager.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                .filter { it.activityInfo.packageName != packageName }
                .distinctBy { it.activityInfo.packageName }
                .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
        } catch (_: Exception) { emptyList() }
        if (apps.isEmpty()) list.addView(label("Tidak ada aplikasi yang ditemukan.", 13f, muted, false), margins(0, 8, 0, 8))
        apps.take(60).forEach { info ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), dp(9), dp(10), dp(9))
                background = shape(card, 12)
                setOnClickListener {
                    try {
                        val launch = packageManager.getLaunchIntentForPackage(info.activityInfo.packageName)
                        if (launch != null) {
                            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            startActivity(launch)
                        }
                    } catch (_: Exception) {
                        Toast.makeText(this@PanelService, "Aplikasi tidak dapat dibuka", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            val icon = try { info.loadIcon(packageManager) } catch (_: Exception) { null }
            val iconView = TextView(this).apply { text = "•"; textSize = 20f; setTextColor(blue); gravity = Gravity.CENTER }
            item.addView(iconView, LinearLayout.LayoutParams(dp(28), dp(28)))
            item.addView(label(info.loadLabel(packageManager).toString(), 14f, white, true), LinearLayout.LayoutParams(0, -2, 1f))
            item.addView(label("BUKA  ›", 11f, blue, true))
            list.addView(item, margins(0, 0, 0, 6))
        }
        scroll.addView(list)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, dp(300)))
        val p = WindowManager.LayoutParams(dp(300), WindowManager.LayoutParams.WRAP_CONTENT, overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.CENTER
        }
        try { wm.addView(outer, p); panel = outer; panelParams = p } catch (_: Exception) {
            Toast.makeText(this, "Panel tidak dapat ditampilkan di atas aplikasi", Toast.LENGTH_LONG).show()
        }
    }

    private val pollRunnable = object : Runnable {
        override fun run() {
            try {
                val top = currentForegroundPackage()
                if (top != null && top != packageName) {
                    val game = isGame(top)
                    if (game && !shownForGame) {
                        bubble?.visibility = View.VISIBLE
                        shownForGame = true
                    } else if (!game && shownForGame) {
                        bubble?.visibility = View.GONE
                        removePanel()
                        shownForGame = false
                    }
                }
            } catch (_: Exception) { }
            handler.postDelayed(this, 1500)
        }
    }

    private fun currentForegroundPackage(): String? {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
        } else {
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
        }
        if (mode != AppOpsManager.MODE_ALLOWED) return null
        val usm = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
        val end = System.currentTimeMillis()
        val events = usm.queryEvents(end - 10_000, end)
        val event = UsageEvents.Event()
        var latestTime = 0L
        var latestPackage: String? = null
        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            val resumed = if (Build.VERSION.SDK_INT >= 29) event.eventType == UsageEvents.Event.ACTIVITY_RESUMED else event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND
            if (resumed && event.timeStamp >= latestTime) {
                latestTime = event.timeStamp
                latestPackage = event.packageName
            }
        }
        return latestPackage
    }

    private fun isGame(pkg: String): Boolean = try {
        val info = if (Build.VERSION.SDK_INT >= 26) packageManager.getApplicationInfo(pkg, 0) else packageManager.getApplicationInfo(pkg, 0)
        Build.VERSION.SDK_INT >= 26 && info.category == ApplicationInfo.CATEGORY_GAME
    } catch (_: Exception) { false }

    private fun removePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) { } }
        panel = null; panelParams = null
    }

    override fun onDestroy() {
        handler.removeCallbacks(pollRunnable)
        removePanel()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) { } }
        bubble = null
        super.onDestroy()
    }

    private fun overlayType() = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun shape(color: Int, radius: Int) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat(); setStroke(dp(1), Color.rgb(49, 72, 107)) }
    private fun label(value: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
    }
    private fun margins(l: Int, t: Int, r: Int, b: Int) = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(l), dp(t), dp(r), dp(b)) }

    private inner class DragTouchListener : View.OnTouchListener {
        private var startX = 0; private var startY = 0; private var downX = 0f; private var downY = 0f; private var moved = false
        override fun onTouch(v: View, e: MotionEvent): Boolean {
            val p = bubbleParams ?: return false
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { startX = p.x; startY = p.y; downX = e.rawX; downY = e.rawY; moved = false; return true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt(); val dy = (e.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) > dp(4) || kotlin.math.abs(dy) > dp(4)) moved = true
                    p.x = startX + dx; p.y = startY + dy
                    try { wm.updateViewLayout(v, p) } catch (_: Exception) { }
                    return true
                }
                MotionEvent.ACTION_UP -> { if (!moved) v.performClick(); return true }
            }
            return false
        }
    }
}
