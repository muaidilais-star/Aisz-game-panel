package com.aisz.gamepanel

import android.app.Activity
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val blue = 0xFF3985FF.toInt()
    private val bg = 0xFF0B1020.toInt()
    private val card = 0xFF172238.toInt()
    private val white = 0xFFFFFFFF.toInt()
    private val muted = 0xFFB9C7DC.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        render()
    }

    override fun onResume() {
        super.onResume()
        // Refresh permission status when returning from Android Settings.
        if (window.decorView.rootView != null) render()
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(28), dp(22), dp(22))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        val title = TextView(this).apply {
            text = "AISZ GAME PANEL"
            textSize = 26f
            setTextColor(white)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        content.addView(title)
        content.addView(text("FLOATING TOOLBOX  •  ANDROID 15", 12f, blue, true), margin(0, 6, 0, 18))
        content.addView(text("Panel pintasan saat bermain game", 18f, white, true), margin(0, 0, 0, 8))
        content.addView(text("Panel dapat muncul di atas game setelah izin diberikan. Tombol aplikasi akan membuka aplikasi yang dipilih secara normal; jendela bebas untuk aplikasi lain tidak dijamin di POCO C65.", 14f, muted, false), margin(0, 0, 0, 18))

        content.addView(permissionCard("1. Izin tampil di atas aplikasi", if (Settings.canDrawOverlays(this)) "Sudah diizinkan" else "Belum diizinkan", Settings.canDrawOverlays(this)))
        val overlay = button(if (Settings.canDrawOverlays(this)) "Periksa izin overlay" else "Izinkan overlay") {
            if (!Settings.canDrawOverlays(this)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) else render()
        }
        content.addView(overlay, margin(0, 8, 0, 14))

        val usageGranted = hasUsageAccess()
        content.addView(permissionCard("2. Akses penggunaan aplikasi", if (usageGranted) "Sudah diizinkan" else "Diperlukan untuk mendeteksi game", usageGranted))
        content.addView(button(if (usageGranted) "Buka pengaturan akses penggunaan" else "Aktifkan akses penggunaan") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }, margin(0, 8, 0, 14))

        content.addView(text("3. Jalankan panel", 18f, white, true), margin(0, 4, 0, 8))
        content.addView(text("Android akan meminta izin notifikasi jika diperlukan. Deteksi game otomatis bergantung pada akses penggunaan dan pembatasan latar belakang dari sistem HP.", 13f, muted, false), margin(0, 0, 0, 10))
        content.addView(button("MULAI AISZ GAME PANEL") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else if (!hasUsageAccess()) {
                startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            } else {
                val i = Intent(this, PanelService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(i) else startService(i)
                finish()
            }
        }, margin(0, 8, 0, 10))
        content.addView(button("HENTIKAN PANEL") { stopService(Intent(this, PanelService::class.java)) }, margin(0, 0, 0, 16))
        content.addView(text("Catatan: aplikasi ini tidak menggunakan root atau Shizuku. Fitur jendela mengambang penuh memerlukan dukungan sistem perangkat.", 12f, muted, false))

        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun hasUsageAccess(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
        } else {
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), packageName)
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }

    private fun permissionCard(label: String, status: String, ok: Boolean) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        setBackgroundColor(card)
        addView(text(label, 15f, white, true))
        addView(text(status, 13f, if (ok) 0xFF6FE0A5.toInt() else 0xFFFFC66D.toInt(), false), margin(0, 4, 0, 0))
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color)
        if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD
    }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label; setTextColor(white); setBackgroundColor(blue); isAllCaps = false
        setOnClickListener { action() }
    }

    private fun margin(l: Int, t: Int, r: Int, b: Int) = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
        setMargins(dp(l), dp(t), dp(r), dp(b))
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
