# No custom ProGuard rules required for the starter project.
